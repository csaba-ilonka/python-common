import config

def apply_defaults():
    config.for_logging()
    config.for_properties()